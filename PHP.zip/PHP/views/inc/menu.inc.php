<?php 
use ism\lib\Role;
use ism\lib\Session;?>
<nav class="navbar navbar-expand-sm navbar-light" style="background-color: #FFE4E1">
    <a class="navbar-brand" href="<?php path('security/login') ?>">GESTIONNAIRE D'ETUDIANTS</a>
    <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavId">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
        <?php  if(!Role::estConnect()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php path('security/register') ?>" style="background-color: #FFE4E1">inscription</a>
            </li>
        <?php endif ?>
        <?php if(Role::estAdmin()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">fonctionnalites</a>
                <div class="dropdown-menu" aria-labelledby="dropdownId">
                    <a class="dropdown-item" href="<?php path('security/adminregister')?>">Ajouter AC ou RP</a>
                    <a class="dropdown-item" href="<?php path('security/showUser')?>">Lister les utilisateurs</a>
                    <a class="dropdown-item" href="<?php path('etudiant/showetudiants')?>">Lister les etudiants</a>
                </div>
            </li>
        <?php endif ?>
        <?php if(Role::estAssistantClasse()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">fonctionnalites</a>
                <div class="dropdown-menu" aria-labelledby="dropdownId">
                    <a class="dropdown-item" href="<?php path('etudiant/addetudiant')?>">Ajouter un etudiant</a>
                    <a class="dropdown-item" href="<?php path('etudiant/showetudiants')?>">Lister les etudiants</a>
                    <a class="dropdown-item" href="<?php path('etudiant/addabsence')?>">Marquer une absence</a>
                    <a class="dropdown-item" href="<?php path('etudiant/showabsences')?>">Lister les absences</a>
                    <a class="dropdown-item" href="<?php path('cour/showcours')?>">Lister les cours plannifiés</a>
                    <a class="dropdown-item" href="<?php path('cour/showcours')?>">Lister les cours d'un professeur</a>
                </div>
            </li>
        <?php endif ?>
        <?php if(Role::estResponsablePedagogique()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Mes fonctionnalites</a>
                <div class="dropdown-menu" aria-labelledby="dropdownId">
                    <a class="dropdown-item" href="<?php path('etudiant/showetudiants')?>">Lister les etudiants</a>
                    <a class="dropdown-item" href="<?php path('etudiant/addabsence')?>">Marquer une absence</a>
                    <a class="dropdown-item" href="<?php path('etudiant/showabsences')?>">Lister les absences</a>
                    <a class="dropdown-item" href="<?php path('professeur/addprofesseur')?>">Ajouter un professeur</a>
                    <a class="dropdown-item" href="<?php path('cour/showcours')?>">Lister les cours d'un professeur</a>
                    <a class="dropdown-item" href="<?php path('cour/showcours')?>">Lister les cours d'une classe</a>
                    <a class="dropdown-item" href="<?php path('cour/planifiercour')?>">Planifier un cours</a>
                </div>
            </li>
        <?php endif ?>
        <?php  if(Role::estEtudiant()): ?>
            <li class="nav-item active">
                <a class="nav-link" href="<?php path('etudiant/showmyabsences/'.Session::getSession("user_connect")['id'])?>">Mes absences</a>
            </li>
        <?php endif ?>
        <?php  if(Role::estConnect()): ?>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="dropdownId" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Parametres</a>
                <div class="dropdown-menu" aria-labelledby="dropdownId">
                     <a class="dropdown-item" href="<?php path('security/modifyAccount')?>">Modifier compte</a>
                     <a class="dropdown-item" href="<?php path('security/logout')?>">Deconnexion</a>
                </div>
            </li>
        <?php endif ?>
        <?php if(!Role::estConnect()): ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php path('security/login') ?>">connection</a>
            </li>
        <?php endif ?>
    </ul>
    <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
        <?php if(Role::estConnect()):?>
            <li class="nav-item">
            <?= Session::getSession("user_connect")["login"];  
            ?>   
            </li>
        <?php endif?>
    </ul>  
</div>
</nav>