<?php 
use ism\lib\Session;
//verification des erreur de session
$array_error = [];
if (Session::keyExist("array_error")){
    //recupeeration des erreur de la session dans la variable local
    $array_error = Session::getSession("array_error");
    Session::destroyKey("array_error");    
}
?>
      <div class="container mt-5">
      <h1 class="text-center alert alert-primary">AJOUTER UN COURS</h1>
      <form action="<?php ROOT_CONTROLLERS.'/cour.php' ?>" method="POST">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Date</label>
                        <input type="date" class="form-control" name="date">
                        <?php if(isset($array_error["date"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["date"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Professeur</label>
                        <select class="form-control" name="professeur">
                            <?php 
                            foreach ($professeurs as $professeur) {
                                echo '<option value="'.$professeur['prenom'].'-'.$professeur['nom'].'">'.$professeur['prenom'].' '.$professeur['nom'].'</option>';
                            }
                            ?>
                        </select>
                        <?php if(isset($array_error["professeur"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["professeur"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Heure debut</label>
                        <input type="number" min="8" max="20" value="8" class="form-control" name="heure_debut">
                        <?php if(isset($array_error["heure_debut"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["heure_debut"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Heure fin</label>
                        <input type="number" min="8" max="20" value="10" class="form-control" name="heure_fin">
                        <?php if(isset($array_error["heure_fin"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["heure_fin"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Nombre d'heures</label>
                        <input type="number" min="1" max="4" value="2" class="form-control" name="nombre_heures">
                        <?php if(isset($array_error["nombre_heures"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["nombre_heures"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label">Semestre</label>
                        <input type="number" min="1" max="6" value="2" class="form-control" name="semestre">
                        <?php if(isset($array_error["semestre"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["semestre"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                    <label  class="form-label">Modules</label>
                    <select class="form-control" name="modules">
                        <?php 
                        foreach ($modules["data"] as $module) {
                            echo '<option value="'.$module['libelle'].'">'.$module['libelle'].'</option>';
                        }
                        ?>
                    </select>
                <?php if(isset($array_error["modules"])):?>
                    <div  class="form-text text-danger ">
                <?= $array_error["modules"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <p>Classes</p>
                <div class="form-check">
                    <?php
                        foreach ($classes as $classe) {
                            echo '<input class="form-check-input" type="checkbox" name="classes[]" value="'.$classe['filiere'].'-'.$classe['niveau'].'" id="inlineCheckbox1">';
                            echo '<label class="form-check-label" for="inlineCheckbox1" >'.$classe['filiere'].'-'.$classe['niveau'].'</label>';
                            echo '<br>';
                        }
                    ?>
                </div>
                <?php if(isset($array_error["classes"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["classes"]; ?></div>
                <?php endif; ?>
            </div><br>
            <div class="row float-right">
             <button type="submit" class="btn btn-dark">Soumettre</button></button>
            </div>
        </form>
      </div>
