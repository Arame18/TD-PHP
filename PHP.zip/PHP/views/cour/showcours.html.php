<h1 class="text-center alert alert-primary">LISTE DES COURS PLANNIFIES</h1>
<table class="table mt-5 container table-bordered">
    <thead>
        <tr>
            <th>Module</th>
            <th>Date</th>
            <th>Professeur</th>
            <th>Classe</th>
            <th>Heure debut</th>
            <th>Heure fin</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($cours as  $cour):?> 
        <tr>
            <td><?= $cour["modules"] ?></td>
            <td><?= $cour["date"] ?></td>
            <td><?= $cour["professeur"] ?></td>
            <td><?= $cour["classes"] ?></td>
            <td><?= $cour["heure_debut"].'h' ?></td>
            <td><?= $cour["heure_fin"].'h' ?></td>
        </tr>
    <?php  endforeach;?>
        
        
    </tbody>
</table>
