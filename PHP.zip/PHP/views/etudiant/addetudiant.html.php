<?php 
use ism\lib\Session;
$array_error = [];
if (Session::keyExist("array_error")){
    $array_error = Session::getSession("array_error");
    Session::destroyKey("array_error");    
}
?>

      <div class="container mt-5">
      <h1 class="text-center alert alert-primary">AJOUTER UN ETUDIANT</h1>

      <form action="<?php ROOT_CONTROLLERS.'/etudiant.php' ?>" method="POST" enctype="multipart/form-data">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label" value="">Nom</label>
                        <input type="text" class="form-control" name="nom">
                        <?php if(isset($array_error["nom"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["nom"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="mb-3">
                        <label  class="form-label" value="">Prénom</label>
                        <input type="text" class="form-control" name="prenom">
                        <?php if(isset($array_error["prenom"])):?>
                            <div  class="form-text text-danger ">
                            <?= $array_error["prenom"]; ?></div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label  class="form-label">Date de naissance</label>
                <input type="date" class="form-control" name="date_de_naissance" >
                <?php if(isset($array_error["date_de_naissance"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["date_de_naissance"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="form-group">
              <label for="">Sexe</label>
              <select class="form-control" name="sexe">
                <option value="feminin">Feminin</option>
                <option value="masculin">Masculin</option>
              </select>
            </div>
            <div class="mb-3">
                <label  class="form-label">Classe</label>
                <select class="form-control" name="classe">
                    <?php 
                        foreach ($classes as $classe) {
                            echo '<option value="'.$classe['filiere'].'-'.$classe['niveau'].'">'.$classe['filiere'].' - '.$classe['niveau'].'</option>';
                        }
                    ?>
                </select>
                <?php if(isset($array_error["classe"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["classe"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <p>Competences de l'etudiant </p>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox1" value="maquettage_et_prototypage">
                    <label class="form-check-label" for="inlineCheckbox1">Maquettage et Prototypage</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="integration_web">
                    <label class="form-check-label" for="inlineCheckbox2">Intégration Web</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox3" value="realiser_des_composants_dynamiques_avec_php">
                    <label class="form-check-label" for="inlineCheckbox3">Réaliser des Composants Dynamiques avec PHP</label>
                </div><br><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox3" value="realiser_des_composants_dacces_base_de_donnees">
                    <label class="form-check-label" for="inlineCheckbox3">Réaliser des Composants d'accès Base de Données</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox3" value="deployer_une_application">
                    <label class="form-check-label" for="inlineCheckbox3">Déployer une Application</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox3" value="gestion_de_projet_agiles">
                    <label class="form-check-label" for="inlineCheckbox3">Gestion de Projet Agiles</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="competences[]" id="inlineCheckbox3" value="versionning">
                    <label class="form-check-label" for="inlineCheckbox3">Versionning</label>
                </div>
                <?php if(isset($array_error["competences"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["competences"]; ?></div>
                <?php endif; ?>
            </div><br>
            <div class="mb-3">
                <label  class="form-label">Ajouter un Avatar (facultative)</label>
                <input type="file" class="form-control" name="avatar">
                <?php if(isset($array_error["avatar"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["avatar"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label  class="form-label">Parcours</label>
                <textarea placeholder="Moins de 250 caracteres !" class="form-control" name="parcours"></textarea>
                <?php if(isset($array_error["parcours"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["parcours"]; ?></div>
                <?php endif; ?>
            </div>
            
            <div class="row float-right">
             <button type="submit" class="btn btn-dark">Soumettre</button></button>
            </div>
        </form>

      </div>
