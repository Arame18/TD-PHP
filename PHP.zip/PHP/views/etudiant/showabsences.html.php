<h1 class="text-center alert alert-primary">LISTE DES ABSENCES</h1>
<table class="table mt-5 container table-bordered">
    <thead>
        <tr>
            <th>Date</th>
            <th>Etudiant</th>
            <th>Cours</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($absences['data'] as  $absence):?>
        <tr>
            <td><?= $absence["date"] ?></td>
            <td><?= $absence["etudiant"] ?></td>
            <td><?= $absence["cours"] ?></td>
        </tr>
    <?php  endforeach;?>
        
        
    </tbody>
</table>
