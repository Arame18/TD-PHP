<h1 class="text-center alert alert-primary">LISTE DES ETUDIANTS</h1>
<table class="table mt-5 container table-bordered">
    <thead>
        <tr>
            <th>Nom</th>
            <th>Prenom</th>
            <th>Date de naissance</th>
            <th>Classe</th>
            <th>Competences</th>
        </tr>
    </thead>
    <tbody>
    <?php foreach ($etudiants['data'] as  $etudiant):?>
        <tr>
            <td><?= $etudiant["nom"] ?></td>
            <td><?= $etudiant["prenom"] ?></td>
            <td><?= $etudiant["date_de_naissance"] ?></td>
            <td><?= $etudiant["classe"] ?></td>
            <td><?= str_replace("\"]", "", str_replace("\",\"", ", ", str_replace("[\"", "", $etudiant["competences"]))) ?></td>
            
        </tr>
    <?php  endforeach;?>
        
        
    </tbody>
</table>
