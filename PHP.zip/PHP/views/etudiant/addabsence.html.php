<?php 
use ism\lib\Session;
$array_error = [];
if (Session::keyExist("array_error")){
    $array_error = Session::getSession("array_error");
    Session::destroyKey("array_error");    
}
?>

      <div class="container mt-5">
      <h1 class="text-center alert alert-primary">MARQUER UNE ABSENCE</h1>

      <form action="<?php ROOT_CONTROLLERS.'/etudiant.php' ?>" method="POST">
            <div class="mb-3">
                <label  class="form-label">Date</label>
                <input type="date" class="form-control" name="date" >
                <?php if(isset($array_error["date"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["date"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label  class="form-label">Etudiant</label>
                <select class="form-control" name="etudiant">
                    <?php 
                        foreach ($etudiants["data"] as $etudiant) {
                            echo '<option value="'.$etudiant['prenom'].'-'.$etudiant['nom'].'-'.$etudiant['classe'].'">'.$etudiant['prenom'].' '.$etudiant['nom'].' - '.$etudiant['classe'].'</option>';
                        }
                    ?>
                </select>
                <?php if(isset($array_error["etudiant"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["etudiant"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label  class="form-label">Cours</label>
                <select class="form-control" name="cours">
                    <?php 
                        foreach ($cours as $cour) {
                            echo '<option value="'.$cour['modules'].'-'.$cour['date'].'">'.$cour['modules'].' - '.$cour['date'].'</option>';
                        }
                    ?>
                </select>
                <?php if(isset($array_error["cours"])):?>
                    <div  class="form-text text-danger ">
                    <?= $array_error["cours"]; ?></div>
                <?php endif; ?>
            </div>
            <div class="row float-right">
             <button type="submit" class="btn btn-dark">Soumettre</button></button>
            </div>
        </form>

      </div>
