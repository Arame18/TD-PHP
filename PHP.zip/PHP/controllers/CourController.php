<?php
namespace ism\controllers;

namespace ism\controllers;
use ism\lib\Role;
use ism\lib\Request;
use ism\lib\Session;
use ism\lib\Response;
use ism\models\EtudiantModel;
use ism\lib\AbstractController;
use ism\models\AbsenceModel;
use ism\models\ClasseModel;
use ism\models\ProfesseurModel;
use ism\models\CourModel;
use ism\models\ModuleModel;

class CourController extends AbstractController {

    public function addcour(Request $request){
        $modelprof = new ProfesseurModel();
        $modelclasse = new ClasseModel();
        $modelmodule = new ModuleModel();
        $modelcour = new CourModel();
        $professeurs = $modelprof->selectAll();
        $classes = $modelclasse->selectAll();
        $modules = $modelmodule->selectAll();
        if($request->isPost()){
            $data=$request->getBody();
            $this->validator->estVide($data["date"], "date");
            $this->validator->estVide($data["professeur"], "professeur");
            $this->validator->estVide($data["heure_debut"], "heure_deb");
            $this->validator->estVide($data["heure_fin"], "heure_fin");
            $this->validator->estVide($data["nombre_heures"], "nombre_heures");
            $this->validator->estVide($data["modules"], "modules");
            $this->validator->estVide($data["semestre"], "semestre");
            if($this->validator->formValide()){
                $data["classes"] = json_encode($data["classes"]);
                $modelcour->insert($data);
                Response::redirectUrl("cour/showcours");
            }else{
                Session::SetSession("array_error",$this->validator->getErrors());
                Session::SetSession("array_post",$data);
                Response::redirectUrl("cour/addcour");  
            }
        }
        $this->render("cour/addcour", ["professeurs"=>$professeurs, "classes"=>$classes, "modules"=>$modules]);
    }

    public function showcours(){
        if(!Role::estResponsablePedagogique()){
            if(!Role::estAssistantClasse()){
                Response::redirectUrl("security/logout");
            }
        }
        $model=new CourModel();
        $data=$model->selectAll();
        $this->render("cour/showcours",["cours"=> $data]);
    }

    /* public function showcoursprofesseur(){
        if(!Role::estResponsablePedagogique()){
            if(!Role::estAssistantClasse()){
                Response::redirectUrl("security/logout");
            }
        }
        $model=new CourModel();
        $data=$model->selectAll();
        $this->render("cour/showcours",["cours"=> $data]);
    } */
}