<?php
namespace ism\controllers;

use ism\lib\Request;
use ism\lib\Response;
use ism\models\BienModel;
use ism\lib\AbstractModel;
use ism\lib\AbstractController;

class BienController extends AbstractController {

    private AbstractModel $model;
    public function __construct(){
        parent::__construct();
        $this->model= new BienModel();
    }

    public function showCatalogue(){
        $data= $this->model->selectAll();
        $this->render("bien/catalogue.bien", ["biens" => $data]);



    }

    public function showDetail(Request $request){
        if(!isset($request->getParams()[0]) || !is_numeric($request->getParams()[0])){
            Response::redirectUrl("bien/showCatalogue");
        }
     $id_bien=$request->getParams()[0];
     $data = $this->model->selectById($id_bien);
    $this->render("bien/detail.bien",["bien"=> $data]);
    }

    public function addBien(){}

    
}
