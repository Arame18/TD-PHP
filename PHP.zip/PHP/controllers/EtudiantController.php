<?php
namespace ism\controllers;

namespace ism\controllers;
use ism\lib\Role;
use ism\lib\Request;
use ism\lib\Session;
use ism\lib\Response;
use ism\models\EtudiantModel;
use ism\lib\AbstractController;
use ism\models\AbsenceModel;
use ism\models\ClasseModel;
use ism\models\CourModel;

class EtudiantController extends AbstractController {

    public function addEtudiant(Request $request){
        $model2 = new ClasseModel();
        $classes = $model2->selectAll();
        if($request->isPost()){
            $model= new EtudiantModel();
            $data=$request->getBody();
            $this->validator->estVide($data["nom"], "nom");
            $this->validator->estVide($data["prenom"], "prenom");
            $this->validator->estVide($data["date_de_naissance"], "date_de_naissance");
            if($this->validator->formValide()){
                $data["avatar"]="";
                $array_ext_img=array("png", "jpeg", "jpg");
                if(isset($_FILES["avatar"])){
                    $array_avatar = explode(".", $_FILES["avatar"]["name"]);
                    if(!in_array(end($array_avatar), $array_ext_img)){
                        $data["avatar"]="default.png";
                    }else{
                        $filename = $_FILES["avatar"]["name"];
                        $tempname = $_FILES["avatar"]["tmp_name"];   
                        $folder = "media/etudiants_avatars/".$filename;
                        move_uploaded_file($tempname, $folder);
                        $data["avatar"] = $filename;
                    }
                }
                $data["competences"] = json_encode($data["competences"]);
                $model->insert($data);
                Response::redirectUrl("etudiant/showetudiants");
            }else{
                Session::SetSession("array_error",$this->validator->getErrors());
                Session::SetSession("array_post",$data);
                Response::redirectUrl("etudiant/addetudiant");  
            }
        }
        $this->render("etudiant/addetudiant", ["classes"=>$classes]);
    }

    public function showEtudiants(){
        if(!Role::estAdmin()){
            if(!Role::estAssistantClasse()){
                Response::redirectUrl("security/logout");
            }
        }
        $model=new EtudiantModel();
        $data=$model->selectAll();
        $this->render("etudiant/showetudiants",["etudiants"=> $data]);
    }

    public function showabsences(){
        if(!Role::estAssistantClasse()){
            if(!Role::estResponsablePedagogique()){
                Response::redirectUrl("security/logout");
            }
        }
        $model=new AbsenceModel();
        $data=$model->selectAll();
        $this->render("etudiant/showabsences",["absences"=> $data]);
    }

    public function addabsence(Request $request){
        if(!Role::estAssistantClasse()){
            if(!Role::estResponsablePedagogique()){
                Response::redirectUrl("security/logout");
            }
        }
        $modeletudiant=new EtudiantModel();
        $modelcour = new CourModel();
        $modelabsence = new AbsenceModel();
        $dataEtu=$modeletudiant->selectAll();
        $dataCour = $modelcour->selectAll();
        if($request->isPost()){
            if(count($_POST)!=3){
                $this->render("etudiant/addabsence",["etudiants"=> $dataEtu, "cours"=>$dataCour]);
            }else{
                $data=$request->getBody();
                $modelabsence->insert($data);
                Response::redirectUrl("etudiant/showabsences");
            }
        }
        $this->render("etudiant/addabsence",["etudiants"=> $dataEtu, "cours"=>$dataCour]);
    }

    /* public function doReservation(Request $request){
        if(!isset($request->getParams()[0]) || !is_numeric($request->getParams()[0])){
            Response::redirectUrl("bien/showCatalogue");
        }
        $id_bien=$request->getParams()[0];
        Session::setSession("id_bien", $id_bien);
        Session::setSession("action", "reservation");
        if(Role::estClient()){
            Response::redirectUrl("reservation/addReservation");
        }elseif(!Role::estAdmin()){
            Response::redirectUrl("security/login");
        }

    } */



    /* public function showAbsencesByEtudiant(Request $request){
        if(!isset($request->getParams()[0]) || !is_numeric($request->getParams()[0])){
            Response::redirectUrl("bien/showCatalogue");
        }
        if(!Role::estClient() && !Role::estAdmin())Response::redirectUrl("security/login");
        $idClient = $request->getParams()[0];
        $model = new ReservationModel();
        $data = $model->selectReservationByClient($idClient);
        $this->render("reservation/mes.reservation",["biens" => $data] );

    } */



}