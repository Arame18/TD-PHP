<?php
namespace ism\models;
use ism\lib\AbstractModel;
use ism\lib\FormatDate;

class AbsenceModel extends AbstractModel {
    public function __construct() {
        parent::__construct();
        $this->tableName = "absence";
        $this->primaryKey = "id";
    }



   public function selectAbsenceByStudent(int $matricule ){
        $sql= "SELECT * FROM absence a, utilisateur u 
        WHERE a.etudiant=u.matricule";
        $result=$this->selectBy($sql,[$matricule]);
        return $result["data"];
    }
    
    public function selectAbsences(){
        $sql= "SELECT * FROM absence a";
        $result=$this->selectAll($sql);
        return $result["data"];
    }

    public function insert(array $reservation):bool{
        extract($reservation);
        $sql= "INSERT INTO absence 
        (date,etudiant,cours)
        VALUES 
        (?,?,?)";
        $result=$this->persit($sql,[$date, $etudiant, $cours]);
        return true;
    }

}