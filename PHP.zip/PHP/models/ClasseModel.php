<?php
namespace ism\models;
use ism\lib\AbstractModel;
class ClasseModel extends AbstractModel{

    public function __construct() {
        parent::__construct();
        $this->tableName = "classe";
        $this->primaryKey = "libelle";
    }

    public function selectAll():array {
        $sql="SELECT * FROM classe";
        $result=$this->selectBy($sql);
        return $result["data"];
    }
    
    public function selectByLibelle(string $libelle):array{
    
        $sql="SELECT * FROM classe c WHERE c.libelle=?";
        $result=$this->selectBy($sql,[$libelle],true);
        return $result["data"];
    }

    public function insert(array $classe):bool{
        extract($classe);
        $sql= "INSERT INTO classe 
        (libelle,niveau,filiere)
        VALUES 
        (?,?,?)";
    
        $result=$this->persit($sql,[$libelle,$niveau,$filiere]);
        
        return $result["count"]==0?false:true;
    }
}