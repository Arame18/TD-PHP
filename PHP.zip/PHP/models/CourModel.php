<?php
namespace ism\models;
use ism\lib\AbstractModel;
class CourModel extends AbstractModel{

    public function __construct() {
        parent::__construct();
        $this->tableName = "cours";
        $this->primaryKey = "id_cour";
    }

    public function selectAll():array {
        $sql="SELECT * FROM cours";
        $result=$this->selectBy($sql);
        return $result["data"];
    }
    
    public function selectByLibelle(string $libelle):array{
    
        $sql="SELECT * FROM cours c WHERE c.libelle=?";
        $result=$this->selectBy($sql,[$libelle],true);
        return $result["data"];
    }

    public function insert(array $classe):bool{
        extract($classe);
        $sql= "INSERT INTO cours 
        (date,classes,professeur,modules,semestre,nombre_heures,heure_debut,heure_fin)
        VALUES 
        (?,?,?,?,?,?,?,?)";
        $result=$this->persit($sql,[$date,$classes,$professeur,$modules,$semestre,$nombre_heures,$heure_debut,$heure_fin]);
        return $result["count"]==0?false:true;
    }
}