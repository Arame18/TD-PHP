<?php
namespace ism\models;
use ism\lib\AbstractModel;
class ModuleModel extends AbstractModel{

    public function __construct() {
        parent::__construct();
        $this->tableName = "module";
        $this->primaryKey = "libelle";
    }

    public function selectModules(string $login):array{
        $sql= "SELECT * FROM module 
        WHERE login=?";
        $result=$this->selectBy($sql,[$login],true);
        return $result["count"]==0?[]:$result["data"];
       }
    
    public function loginExiste(string $login):bool{
        $sql= "SELECT * FROM utilisateur WHERE login=:login";
        $result=$this->selectBy($sql,[':login'=>$login],true);
        return $result["count"]==0?false:true;
    }
    
    public function insert(array $user):bool{
        extract($user);
        $sql= "INSERT INTO utilisateur 
        (nom,login,password,avatar,role)
        VALUES 
        (?,?,?,?,?)";
    
        $result=$this->persit($sql,[$nom,$login,$password,$avatar,$role]);
        
        return $result["count"]==0?false:true;
    }
    


}
