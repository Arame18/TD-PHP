<?php
namespace ism\models;
use ism\lib\AbstractModel;
require_once("../lib/AbstractModel.php");
class EtudiantModel extends AbstractModel{

    public function __construct() {
        parent::__construct();
        $this->tableName = "etudiants";
        $this->primaryKey = "matricule";
    }

    public function selectUserByLogin(string $login):array{
        $sql= "SELECT * FROM etudiants 
        WHERE login=?";
        $result=$this->selectBy($sql,[$login],true);
        return $result["count"]==0?[]:$result["data"];
       }
    
    public function loginExiste(string $login):bool{
        $sql= "SELECT * FROM etudiants WHERE login=:login";
        $result=$this->selectBy($sql,[':login'=>$login],true);
        return $result["count"]==0?false:true;
    }
    
    public function insert(array $user):bool{
        extract($user);
        $sql= "INSERT INTO etudiants 
        (nom,prenom,date_de_naissance,sexe,classe,competences,avatar,parcours)
        VALUES 
        (?,?,?,?,?,?,?,?)";
        $result=$this->persit($sql,[$nom,$prenom,$date_de_naissance,$sexe,$classe,$competences,$avatar,$parcours]);
        return $result["count"]==0?false:true;
    }
    


}
